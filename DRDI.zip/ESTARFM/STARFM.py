# -*- coding: utf-8 -*-
"""
Created on 2023.7.18
Adapted from starfm4py (Nikolina Mileva; https://github.com/nmileva/starfm4py)
@author: Mao Huihui
"""
import os
import sys
import time
import numpy as np
from tqdm import tqdm
from osgeo import gdal

## Parameters
# Searching window size (Using Odd Number)
windowSize = 51

# Set to True if you want to decrease the sensitivity to the spectral distance
logWeight = False

# The spatial impact factor is a constant defining the relative importance of spatial distance (in meters)
# Take a smaller value of the spatial impact factor for heterogeneous regions (e.g. A = 150 m)
spatImp = 750

# Increasing the number of classes limits the number of similar pixels
numberClass = 5

# Set the uncertainty value for the fine resolution sensor
# 1) A comprehensive evaluation of two MODIS evapotranspiration products over the conterminous United States:
# Using point and gridded FLUXNET and water balance ET (25% on basin scale; https://doi.org/10.1016/j.rse.2013.07.013)
uncertaintyFineRes = 0.03

# Set the uncertainty value for the coarse resolution sensor
# 1) A comprehensive evaluation of two MODIS evapotranspiration products over the conterminous United States:
# Using point and gridded FLUXNET and water balance ET (25% on basin scale; https://doi.org/10.1016/j.rse.2013.07.013)
uncertaintyCoarseRes = 0.03

# Other global variables
mid_idx = windowSize // 2  # Central Pixel
specUncertainty = np.sqrt(uncertaintyFineRes ** 2 + uncertaintyCoarseRes ** 2)
tempUncertainty = np.sqrt(2 * uncertaintyCoarseRes ** 2)


#  栅格数据访问
class RasterTiff:
    gdal.AllRegister()

    # 读栅格文件
    def read_img(self, filename):
        dataset = gdal.Open(filename)  # 打开文件

        im_width = dataset.RasterXSize  # 栅格矩阵的列数
        im_height = dataset.RasterYSize  # 栅格矩阵的行数
        im_bands = dataset.RasterCount  # 波段数

        im_geotrans = dataset.GetGeoTransform()  # 仿射矩阵，左上角像素的大地坐标和像素分辨率
        im_proj = dataset.GetProjection()  # 地图投影信息，字符串表示
        im_data = dataset.ReadAsArray(0, 0, im_width, im_height)  # 将数据写成数组，对应栅格矩阵

        im_nodata = dataset.GetRasterBand(1).GetNoDataValue()

        type(im_data), im_data.shape

        del dataset
        return im_height, im_width, im_bands, im_geotrans, im_proj, im_nodata, im_data

    # 写栅格文件
    def write_img(self, filename, im_proj, im_geotrans, im_nodata, im_data):
        # gdal数据类型包括：gdal.GDT_Byte, gdal.GDT_UInt16, gdal.GDT_UInt32,
        # gdal.GDT_Int32, gdal.GDT_Float32, gdal.GDT_Float64

        # 判断栅格数据的数据类型
        if 'int8' in im_data.dtype.name:
            datatype = gdal.GDT_Byte
        elif 'int16' in im_data.dtype.name:
            datatype = gdal.GDT_UInt16
        else:
            datatype = gdal.GDT_Float32

        # 判断数组维数
        if len(im_data.shape) == 3:
            im_bands, im_height, im_width = im_data.shape
        else:
            im_bands, (im_height, im_width) = 1, im_data.shape

        # 创建文件
        driver = gdal.GetDriverByName('GTiff')  # 数据类型必须有
        dataset = driver.Create(filename, im_width, im_height, im_bands, datatype)

        dataset.SetGeoTransform(im_geotrans)  # 写入仿射变换参数
        dataset.SetProjection(im_proj)  # 写入投影

        if im_bands == 1:
            dataset.GetRasterBand(1).SetNoDataValue(im_nodata)  # Nodata
            dataset.GetRasterBand(1).WriteArray(im_data)  # 写入数组数据
        else:
            for i in range(im_bands):
                dataset.GetRasterBand(i + 1).SetNoDataValue(im_nodata)  # Nodata
                dataset.GetRasterBand(i + 1).WriteArray(im_data[i])

        del dataset


# Calculate the spectral distance
def spectral_distance(fine_img_t0_win, coarse_img_t0_win):
    spec_diff = fine_img_t0_win - coarse_img_t0_win
    spec_dist = np.abs(spec_diff) + 1.0
    # print('Spectral Distance:', spec_dist.shape)
    return spec_diff, spec_dist


# Calculate the temporal distance
def temporal_distance(coarse_img_t0_win, coarse_img_t1_win):
    temp_diff = coarse_img_t1_win - coarse_img_t0_win
    temp_dist = np.abs(temp_diff) + 1.0
    # print('Temporal Distance:', temp_dist.shape)
    return temp_diff, temp_dist


# Calculate the spatial distance
def spatial_distance():
    coord = np.sqrt((np.mgrid[0:windowSize, 0:windowSize] - windowSize // 2) ** 2)
    spat_dist = np.sqrt(((0 - coord[0]) ** 2 + (0 - coord[1]) ** 2))
    rel_spat_dist = spat_dist / spatImp + 1.0  # relative spatial distance
    # print('Spatial Distance:', rel_spat_dist.shape)
    return rel_spat_dist


# 标准差是根据整景影像计算的，而不是在移动窗口计算的
# Define the threshold used in the dynamic classification process
def similarity_threshold(fine_image_t0):
    fine_image_t0 = np.where(fine_image_t0 == -99, np.nan, fine_image_t0)
    st_dev = np.nanstd(fine_image_t0)
    sim_threshold = st_dev * 2 / numberClass
    # print('Similarity Threshold:', sim_threshold)
    return sim_threshold


# Define the spectrally similar pixels within a moving window
def similarity_pixels(fine_img_t0_win, sim_thre):
    # possible to implement as sparse matrix
    similar_pixels = np.where(np.abs(fine_img_t0_win - fine_img_t0_win[mid_idx, mid_idx]) <= sim_thre, 1, 0)
    # print('Similarity Pixels:', similar_pixels.shape)
    return similar_pixels


# Apply filtering on similar pixels
def filtering(fine_img_t0_win, spec_dist, temp_dist, spec_diff, temp_diff, sim_thre):
    similar_pixels = similarity_pixels(fine_img_t0_win, sim_thre)
    max_spec_dist = np.abs(spec_diff)[mid_idx, mid_idx] + specUncertainty + 1
    max_temp_dist = np.abs(temp_diff)[mid_idx, mid_idx] + tempUncertainty + 1
    spec_filter = np.where(spec_dist < max_spec_dist, 1, 0)
    temp_filter = np.where(temp_dist < max_temp_dist, 1, 0)

    st_filter = spec_filter * temp_filter
    similar_pixels_filtered = similar_pixels * st_filter
    # print('Filtering:', similar_pixels_filtered.shape)
    return similar_pixels_filtered


# Calculate the combined distance
def comb_distance(spec_dist, temp_dist, spat_dist):
    if logWeight:
        # print('logWeight')
        spec_dist = np.log(spec_dist)
        temp_dist = np.log(temp_dist)

    comb_dist = spec_dist * temp_dist * spat_dist
    # print('Comb Distance:', comb_dist.shape)
    return comb_dist


# Calculate weights
def weighting(spec_dist, temp_dist, comb_dist, similar_pixels_filtered):
    # Calculate weights only for the filtered spectrally similar pixels
    weights_filt = comb_dist * similar_pixels_filtered

    # Normalize weights
    reverse_dist_weights = np.divide(1, weights_filt,
                                     out=np.zeros_like(weights_filt),
                                     where=weights_filt != 0)  # 防止分母为0
    norm_weights = np.divide(reverse_dist_weights, np.sum(reverse_dist_weights),
                             out=np.zeros_like(reverse_dist_weights),
                             where=(np.sum(reverse_dist_weights) != 0))  # 防止分母为0

    # Assign max weight (1) when the temporal or spectral distance is zero
    if spec_dist[mid_idx, mid_idx] == 1 or temp_dist[mid_idx, mid_idx] == 1:
        norm_weights = np.zeros(shape=comb_dist.shape)
        norm_weights[mid_idx, mid_idx] = 1

    # print('Weighting:', norm_weights.shape)
    return norm_weights


# Main Function
if __name__ == '__main__':
    stime = time.time()
    raster = RasterTiff()

    # Path
    coarse_image_path = r'E:\test\modis'
    fine_image_path = r'E:\test\ls'
    prediction_output_path = r'E:\test\temporary'

    # Image Name
    coarse_image_t0_name = 'b1_180101.tif'
    coarse_image_t1_name = 'b1_180102.tif'
    fine_image_t0_name = 'B1_180101.tif'

    # Base Image
    # im_height, im_width, im_bands, im_geotrans, im_proj, im_nodata, im_data
    base_image = raster.read_img(os.path.join(fine_image_path, fine_image_t0_name))
    im_nodata = base_image[-2]  # -99
    print('im_nodata:', im_nodata)
    image_shape = base_image[-1].shape
    print('image_shape:', image_shape)
    print('\n')

    # Read image
    coarse_image_t0 = raster.read_img(os.path.join(coarse_image_path, coarse_image_t0_name))[-1]
    coarse_image_t1 = raster.read_img(os.path.join(coarse_image_path, coarse_image_t1_name))[-1]
    fine_image_t0 = raster.read_img(os.path.join(fine_image_path, fine_image_t0_name))[-1]

    # Edge Pad With 0
    coarse_image_t0_pad = np.pad(coarse_image_t0, windowSize // 2, mode='constant', constant_values=-99)
    coarse_image_t1_pad = np.pad(coarse_image_t1, windowSize // 2, mode='constant', constant_values=-99)
    fine_image_t0_pad = np.pad(fine_image_t0, windowSize // 2, mode='constant', constant_values=-99)

    # Spectral Distance
    spec = spectral_distance(fine_image_t0_pad, coarse_image_t0_pad)
    spec_diff = spec[0]
    spec_dist = spec[1]

    # Temporal Distance
    temp = temporal_distance(coarse_image_t0_pad, coarse_image_t1_pad)
    temp_diff = temp[0]
    temp_dist = temp[1]

    # Spatial Distance
    spat_dist = spatial_distance()
    print('\n')

    # Similarity Threshold
    sim_threshold = similarity_threshold(fine_image_t0)

    # Perform the prediction with STARFM (One Pair)
    print('Processing...')
    STARFM_prediction = np.zeros(shape=image_shape) + im_nodata
    # for row_idx in range(windowSize // 2, image_shape[0] + windowSize // 2):
    # Progressor
    for row_idx in tqdm(range(windowSize // 2, image_shape[0] + windowSize // 2)):
        for col_idx in range(windowSize // 2, image_shape[1] + windowSize // 2):
            # Searching window
            coarse_image_t0_window = coarse_image_t0_pad[row_idx - windowSize // 2:row_idx + windowSize // 2 + 1,
                                     col_idx - windowSize // 2:col_idx + windowSize // 2 + 1]
            coarse_image_t1_window = coarse_image_t1_pad[row_idx - windowSize // 2:row_idx + windowSize // 2 + 1,
                                     col_idx - windowSize // 2:col_idx + windowSize // 2 + 1]
            fine_image_t0_window = fine_image_t0_pad[row_idx - windowSize // 2:row_idx + windowSize // 2 + 1,
                                   col_idx - windowSize // 2:col_idx + windowSize // 2 + 1]

            # Spectral Distance Window
            spec_dist_window = spec_dist[row_idx - windowSize // 2:row_idx + windowSize // 2 + 1,
                               col_idx - windowSize // 2:col_idx + windowSize // 2 + 1]
            spec_diff_window = spec_diff[row_idx - windowSize // 2:row_idx + windowSize // 2 + 1,
                               col_idx - windowSize // 2:col_idx + windowSize // 2 + 1]

            # Temporal Distance Window
            temp_dist_window = temp_dist[row_idx - windowSize // 2:row_idx + windowSize // 2 + 1,
                               col_idx - windowSize // 2:col_idx + windowSize // 2 + 1]
            temp_diff_window = temp_diff[row_idx - windowSize // 2:row_idx + windowSize // 2 + 1,
                               col_idx - windowSize // 2:col_idx + windowSize // 2 + 1]

            # Spectrally Similar Pixels
            # 1. Dynamic Classification Process (threshold)
            # 2. Sample Filtering (spectral and temporal)
            # print('1) Spectrally Similar Pixels:')
            similar_pixels = filtering(fine_image_t0_window, spec_dist_window, temp_dist_window, spec_diff_window,
                                       temp_diff_window, sim_threshold)

            # Weight
            # print('2) Weight:')
            comb_dist = comb_distance(spec_dist_window, temp_dist_window, spat_dist)
            weights = weighting(spec_dist_window, temp_dist_window, comb_dist, similar_pixels)

            # Prediction
            # print('3) Prediction:')
            pred_image_window = fine_image_t0_window + temp_diff_window
            pred_image_window[pred_image_window < 0] = 0  # Set prediction value less 0 to 0
            weighted_pred_window = np.sum(pred_image_window * weights)
            STARFM_prediction[row_idx - windowSize // 2, col_idx - windowSize // 2] = weighted_pred_window
            # print('\n')

    # Write STARFM prediction image
    # filename, im_proj, im_geotrans, im_nodata, im_data
    raster.write_img(os.path.join(prediction_output_path,
                                  f'B1_180102.tif_{windowSize}_{logWeight}.tif'),
                     base_image[4], base_image[3], -99, STARFM_prediction)

    etime = time.time()
    print('Processing Time: {ptime} min!'.format(ptime=round((etime - stime) / 60.0, 2)))