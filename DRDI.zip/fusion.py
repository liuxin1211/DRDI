import os
import re
from osgeo import gdal
import glob
import numpy as np
from dbn import SupervisedDBNRegression
import pandas as pd
from deepforest import CascadeForestRegressor
import joblib
from scipy.stats import gaussian_kde
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.model_selection import train_test_split
# 定义读取tiff文件函数
def read_tiff(file_path):
    # 打开GeoTIFF波段1，索引为1
    # 波段索引从1开始，而不是0
    tiff = gdal.Open(file_path)
    tiff_width = tiff.RasterXSize  # 栅格矩阵的列数
    tiff_height = tiff.RasterYSize  # 栅格矩阵的行数
    # tiff_bands = tiff.RasterCount  # 波段数
    if tiff_width == 153 and tiff_height == 152:
        tiff_data = tiff.ReadAsArray(0, 0, tiff_width, tiff_height)  # 获取数据
    elif tiff_width == 154 and tiff_height == 153:
        tiff_data = tiff.ReadAsArray(0, 0, tiff_width-1, tiff_height - 1)  # 获取数据
    elif tiff_width == 155 and tiff_height == 153:
        tiff_data = tiff.ReadAsArray(0, 0, tiff_width - 2, tiff_height - 1)  # 获取数据
    elif tiff_width == 155 and tiff_height == 152:
        tiff_data = tiff.ReadAsArray(0, 0, tiff_width - 2, tiff_height)  # 获取数据
    elif tiff_width == 154 and tiff_height == 152:
        tiff_data = tiff.ReadAsArray(0, 0, tiff_width - 1, tiff_height)  # 获取数据
    else:
        print("这个文件大小既不是340*437，也不是340*438：", file_path, "。请检查代码以及文件。")
        tiff_data = None
    tiff_data = np.where(np.isnan(tiff_data), 0.1, tiff_data)
    tiff_data = np.where(tiff_data < -999, 0.1, tiff_data)
    return tiff, tiff_data


"""DATA：["fal","sw","t2m","ndvi","month","ele","doy"],经过相关性分析，最终选取["fal","sw","t2m","month","doy"]"""

lat_folder_path = r"E:\HOAL_sm\30m_DATA\lat\*.tif"
lon_folder_path = r"E:\HOAL_sm\30m_DATA\lon\*.tif"
ele_folder_path = r"E:\HOAL_sm\30m_DATA\DEM\*.tif"
fal_folder_path = r"E:\HOAL_sm\30m_DATA\Albedo\*.tif"
ndvi_folder_path = r"E:\HOAL_sm\30m_DATA\NDVI\*.tif"
skt_folder_path = r"E:\HOAL_sm\30m_DATA\skt\*.tif"
tem_folder_path = r"E:\HOAL_sm\30m_DATA\stl2\*.tif"
sw_folder_path = r"E:\HOAL_sm\30m_DATA\sw2\*.tif"
tp_folder_path = r"E:\HOAL_sm\30m_DATA\tp\*.tif"
rzsm_folder_path = r"E:\HOAL_sm\mm_smap\smap_ssm_30m\*.tif"

# sat_folder_path = r"H:\at_data_fusion\fusion\sat\*.tif"

lat_path_list = glob.glob(lat_folder_path)*365
lon_path_list = glob.glob(lon_folder_path)*365
ele_path_list = glob.glob(ele_folder_path) * 365
fal_path_list = glob.glob(fal_folder_path)
ndvi_path_list = glob.glob(ndvi_folder_path)
skt_path_list = glob.glob(skt_folder_path)
tem_path_list = glob.glob(tem_folder_path)
sw_path_list = glob.glob(sw_folder_path)
tp_path_list = glob.glob(tp_folder_path)
rzsm_path_list = glob.glob(rzsm_folder_path)
doy_list = list(range(1, 366))

# NDVI 16DAY spatial resolution
ndvi_path_list16 = sorted(ndvi_path_list * 16)[:-3]
evi_path_list = glob.glob(evi_folder_path)  # NDVI为16天分辨率，因此需要延长16倍,即总共23个文件*16=368个文件，再去掉最后多余的三个
evi_path_list16 = sorted(evi_path_list * 16)[:-3]  # 将NDVI进行延长并去掉最后三个
# DEM
lst_path_list = glob.glob(lst_folder_path)
tat_path_list = glob.glob(tat_folder_path)
sat_path_list = glob.glob(sat_folder_path)

fal_path_list1 =fal_path_list
ndvi_path_list1 = ndvi_path_list
skt_path_list1 =skt_path_list
tem_path_list1 = tem_path_list
sw_path_list1 = sw_path_list

tp_path_list1 =tp_path_list
rzsm_path_list1 =rzsm_path_list

# Convert filenames sorted as strings to numeric order using regular expressions
# regx1 = "fal_(.*).tif"
# regx2 = "sw_(.*).tif"
# regx3 = "t2m_(.*).tif"
# regx4 = "u10_(.*).tif"
# regx5 = "v10_(.*).tif"
# regx6 = "lst_(.*).tif"
# regx7 = "T_at_(.*).tif"
# regx8 = "tem_(.*).tif"
# fal_path_list1 = sorted(fal_path_list, key=lambda info: (int(re.findall(regx1, info)[0])))
# sw_path_list1 = sorted(sw_path_list, key=lambda info: (int(re.findall(regx2, info)[0])))
# t2m_path_list1 = sorted(t2m_path_list, key=lambda info: (int(re.findall(regx3, info)[0])))
# u10_path_list1 = sorted(u10_path_list, key=lambda info: (int(re.findall(regx4, info)[0])))
# v10_path_list1 = sorted(v10_path_list, key=lambda info: (int(re.findall(regx5, info)[0])))
# lst_path_list1 = sorted(lst_path_list, key=lambda info: (int(re.findall(regx6, info)[0])))
# tat_path_list1 = sorted(tat_path_list, key=lambda info: (int(re.findall(regx7, info)[0])))
# sat_path_list1 = sorted(sat_path_list, key=lambda info: (int(re.findall(regx8, info)[0])))

def model(data):
    from sklearn.preprocessing import MinMaxScaler
    data_all = pd.read_csv(r"E:\HOAL_sm\sm_30m_research\deepth_alldoy\deep_0.05_test-8.csv")
    predictors = data_all[["Lat","Lon","Ele","fal","ndvi","skt","tp","rzsm","doy"]].values
    min_max_scaler = MinMaxScaler()
    predictors = min_max_scaler.fit_transform(predictors)
    in_data = min_max_scaler.transform(data)
    in_data = in_data.reshape((in_data.shape[0], 1, in_data.shape[1]))

    regressor = SupervisedDBNRegression.load(r"E:\HOAL_sm\sm_30m_research\model/sm10cm.joblib")
    regressor = joblib.load(r"E:\HOAL_sm\sm_30m_research\model/sm05cm.joblib")
    regressor = tf.keras.models.load_model(r"F:\revision\Los\lstm_model.h5")
    out_data = regressor.predict(in_data)

    return out_data


def create_tif(tif_path, tif_name, row, col, geotransform, projection, matrix_name):
    # 生成tif
    out_file_tif_path = os.path.join(tif_path, "sm05cm_" + tif_name)
    # row = 437
    # col = 340
    driver = gdal.GetDriverByName("GTiff")
    out_tif = driver.Create(out_file_tif_path, row, col, 1, gdal.GDT_Float64)
    out_tif.SetGeoTransform(geotransform)
    out_tif.SetProjection(projection)

    matrix_name=np.where(matrix_name > 10000, np.nan, matrix_name)
    matrix_name=np.where(matrix_name < -500, np.nan, matrix_name)
    out_tif.GetRasterBand(1).WriteArray(matrix_name)
    # out_tif.GetRasterBand(1).WriteArray(matrix_name)
    print(out_file_tif_path)
    del out_tif


# 主函数，调用模型批量生成融合数据
def use_model_to_tif():
    for lat_path,lon_path,ele_path,fal_path, ndvi_path,skt_path,tp_path, rzsm_path,doy in zip(lat_path_list,lon_path_list,
            ele_path_list,fal_path_list1,ndvi_path_list1,skt_path_list1,
           tp_path_list1,rzsm_path_list1,doy_list
    ):
        lat_tiff, lat_tiff_data = read_tiff(lat_path)
        lon_tiff, lon_tiff_data = read_tiff(lon_path)
        ele_tiff, ele_tiff_data = read_tiff(ele_path)
        fal_tiff, fal_tiff_data = read_tiff(fal_path)
        ndvi_tiff, ndvi_tiff_data = read_tiff(ndvi_path)
        skt_tiff, skt_tiff_data = read_tiff(skt_path)
        # tem_tiff, tem_tiff_data = read_tiff(tem_path)
        # sw_tiff, sw_tiff_data = read_tiff(sw_path)
        tp_tiff, tp_tiff_data = read_tiff(tp_path)
        rzsm_tiff, rzsm_tiff_data = read_tiff(rzsm_path)

        all_tiff = np.stack(
            (lat_tiff_data,lon_tiff_data,ele_tiff_data, fal_tiff_data,ndvi_tiff_data, skt_tiff_data,  tp_tiff_data,
             rzsm_tiff_data)
        )

        all_tiff_1 = all_tiff.reshape((8, -1))
        # print(all_tiff_1.T.shape)
        month_doy = (np.array([doy] * 23256)).reshape((23256, 1))
        in_matrix = np.concatenate((all_tiff_1.T, month_doy), axis=1)
        predict_data = model(in_matrix)
        # print("predict_data:", predict_data)
        # print("shape", predict_data.shape)
        # print("type", type(predict_data))
        # for i in range(all_tiff_1.shape[1]):
        predict_data_tif = predict_data.reshape((152, 153))

        tif_name = os.path.basename(skt_path)[3:]

        create_tif(
            tif_path=r"E:\HOAL_sm\3HSM\lstm05cm", tif_name=tif_name, row=skt_tiff.RasterXSize,
            col=skt_tiff.RasterYSize,
            geotransform=skt_tiff.GetGeoTransform(), projection=skt_tiff.GetProjection(), matrix_name=predict_data_tif
        )
        # break

use_model_to_tif()