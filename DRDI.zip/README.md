# Multi-layer Soil Moisture Fusion Framework


This repository presents a complete data fusion framework to generate high-resolution (30 m) and multi-layer soil moisture (SM) datasets for agricultural drought assessment. The framework integrates multi-source satellite, reanalysis, and in-situ data using a hybrid of machine learning and deep learning techniques.

---

# Key Features

- Generation of **daily, 30 m spatial resolution** SM data across multiple soil layers (5cm, 10cm, 20cm, 50cm).
- Incorporation of both **surface-surface** and **point-surface** fusion.
- Integration of crop-specific **root depth information** to calculate a new drought index (DRDI).
- Models used:
  - ESTARFM for spatio-temporal variable fusion
  - Extremely Randomized Trees (ERT) for downscaling SMAP data
  - Deep Forest (DF) for point-surface fusion and calibration


## Method Overview

### Step 1: Spatio-Temporal Fusion (ESTARFM)
Fuses MODIS and Landsat data to obtain NDVI, LST, and Albedo with 30 m daily resolution.

### Step 2: Downscaling SMAP-L4 (ERT Model)
Downscales 9 km SMAP L4 soil moisture (surface and root zone) to 30 m resolution using machine learning and auxiliary inputs (e.g., LST, precipitation, NDVI, Albedo).

### Step 3: Point-Surface Fusion (Deep Forest)
Corrects and calibrates downscaled SM using in-situ observations to improve accuracy and spatial representativeness.



