import pandas as pd
import numpy as np
import joblib
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error,mean_absolute_error
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import ExtraTreesRegressor
# from dbn import SupervisedDBNRegression
from scipy.stats import pearsonr
import matplotlib.pyplot as plt #画图
from matplotlib import font_manager as fm
from matplotlib.colors import LogNorm
from scipy.stats import gaussian_kde#散点密度图
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler
import os
import gdal

data=pd.read_csv(r"F:\1_yanzheng\EXCEL\ALL_5.csv")
predictors = data[["ERA5_1","PRE_chrips","GT-LST"]].values
outputvar=data["GLEAM_sur"].values
# data=pd.read_csv(r"E:\HOAL_sm\hoal_sta\HOAL_csv\deep_0.1\deep_0.1_test.csv")
# predictors = data[["doy","fal","ndvi","skt","tem","sw","tp","rzsm"]].values
# outputvar=data["SM"].values
min_max_scaler = MinMaxScaler()
predictors = min_max_scaler.fit_transform(predictors) #区别
X_train, X_test, Y_train, Y_test = train_test_split(predictors, outputvar, test_size=0.2,random_state=888)

# Training
regressor = ExtraTreesRegressor(random_state=1)
#scores = cross_val_score(regressor,X_train, Y_train,cv=10,scoring='r2') #cv：默认是3折交叉验证，变成5折交叉验证。得分为均方差
regressor.fit(X_train, Y_train)

joblib.dump(regressor,r"E:\HOAL_sm\mm_smap/model_RF_RZ.joblib")
regressor=joblib.load(r"E:\HOAL_sm\mm_smap/model_RF_RZ.joblib")
regressor.save("H:/at_data_fusion/model_1.pkl")
regressor = SupervisedDBNRegression.load("H:/at_data_fusion/model_1.pkl")


Y_pred = regressor.predict(X_test).flatten()#给予新的数据用于预测
Y_pred2 = regressor.predict(X_train)
RMSE = np.sqrt(mean_squared_error(Y_test, Y_pred))
MAE = mean_absolute_error(Y_test, Y_pred)

X_mean = np.mean(Y_test)
Y_mean = np.mean(Y_pred)
numerator = np.sum((Y_test - X_mean) * (Y_pred - Y_mean))
denominator = np.sqrt(np.sum((Y_test - X_mean) ** 2) * np.sum((Y_pred - Y_mean) ** 2))
PCC = numerator / denominator

SS_res = np.sum((Y_test - Y_pred) ** 2)
SS_tot = np.sum((Y_test - np.mean(Y_test)) ** 2)
R2 = 1 - (SS_res / SS_tot)

BIAS = float(np.mean(Y_test - Y_pred))
print("RMSE=",RMSE)
print("MAE=",MAE)
print("R2=",R2)
print("BIAS=",BIAS)
print("PCC=",PCC)
# print("score_R2=",scores,"r2mean",scores.mean())
b=Y_pred
c=Y_test
xy = np.vstack([Y_test,Y_pred])
z = gaussian_kde(xy)(xy)

# Sort the points by density, so that the densest points are plotted last
idx = z.argsort()
x, y, z = Y_test[idx], Y_pred[idx], z[idx]
scalar = MinMaxScaler()
z = z.reshape(-1, 1)
z = scalar.fit_transform(z)[:, 0]

fig, ax = plt.subplots()
plt.scatter(x, y,c=z,  s=40, cmap='coolwarm')
plt.plot(np.arange(0.1,0.5,0.1),np.arange(0.1,0.5,0.1),color="black",linestyle="--")
plt.xticks(family='Times New Roman',size=18)
plt.yticks(family='Times New Roman',size=18)
# plt.tick_params(labelsize=18)
plt.grid(linestyle="--")
plt.text(x=-5, y=22, fontsize=20, s='R2=%.3f\nRMSE=%.3f℃\nMAE=%.3f℃' % (PCC, RMSE, MAE),
         fontdict={'family': 'Times New Roman'})
# plt.colorbar()
cbar = plt.colorbar()

prop = fm.FontProperties(fname=fm.findfont(fm.FontProperties(family='Times New Roman')))

for label in cbar.ax.get_yticklabels():
    label.set_fontproperties(prop)
    label.set_fontsize(18)
plt.show()
