import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from scipy.stats import pearsonr
from sklearn.preprocessing import MinMaxScaler
from deepforest import CascadeForestRegressor

data = pd.read_csv(r"E:\HOAL_sm\sm_30m_research\csv_out\deep_0.1_test.csv")
station_ids = data['Sta'].unique()

results_df = pd.DataFrame(columns=['Test_Station', 'RMSE', 'MAE', 'PCC', 'R2', 'BIAS'])

for test_station_id in station_ids:
    test_data = data[data['Sta'] == test_station_id]
    # X_test = test_data[["Lat", "Lon", "doy", "Ele", "fal", "ndvi", "skt", "tem", "sw", "tp", "rzsm","S_SM","T_SM"]].values
    X_test = test_data[["Ele", "fal", "ndvi", "skt", "tem", "sw", "tp", "rzsm"]].values
    Y_test = test_data['SM'].values

    train_data = data[data['Sta'] != test_station_id]
    # X_train = train_data[["Lat", "Lon", "doy", "Ele", "fal", "ndvi", "skt", "tem", "sw", "tp", "rzsm","S_SM","T_SM"]].values
    X_train = train_data[[ "Ele", "fal", "ndvi", "skt", "tem", "sw", "tp", "rzsm"]].values
    Y_train = train_data['SM'].values

    min_max_scaler = MinMaxScaler()
    X_train = min_max_scaler.fit_transform(X_train)
    X_test = min_max_scaler.transform(X_test)

    regressor = CascadeForestRegressor(n_estimators=3, n_trees=500,random_state=1)
    regressor.fit(X_train, Y_train)

    Y_pred = regressor.predict(X_test).flatten()

    RMSE = np.sqrt(mean_squared_error(Y_test, Y_pred))
    MAE = mean_absolute_error(Y_test, Y_pred)

    X_mean = np.mean(Y_test)
    Y_mean = np.mean(Y_pred)
    numerator = np.sum((Y_test - X_mean) * (Y_pred - Y_mean))
    denominator = np.sqrt(np.sum((Y_test - X_mean) ** 2) * np.sum((Y_pred - Y_mean) ** 2))
    PCC = numerator / denominator

    SS_res = np.sum((Y_test - Y_pred) ** 2)
    SS_tot = np.sum((Y_test - np.mean(Y_test)) ** 2)
    R2 = 1 - (SS_res / SS_tot)

    BIAS = float(np.mean(Y_test - Y_pred))

    results_df = results_df.append(
        {'Test_Station': test_station_id, 'RMSE': RMSE, 'MAE': MAE, 'PCC': PCC, 'R2': R2, 'BIAS': BIAS},
        ignore_index=True)

results_df.to_csv(r'E:\HOAL_sm\test\station_0.1.csv', index=False)

